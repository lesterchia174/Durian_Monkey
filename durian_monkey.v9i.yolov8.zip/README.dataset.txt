# durian_monkey > 2024-12-27 6:19pm
https://universe.roboflow.com/created-new-project/durian_monkey

Provided by a Roboflow user
License: CC BY 4.0

