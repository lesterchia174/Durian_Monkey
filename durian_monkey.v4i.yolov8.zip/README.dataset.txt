# durian_monkey > 2024-12-22 10:21pm
https://universe.roboflow.com/created-new-project/durian_monkey

Provided by a Roboflow user
License: CC BY 4.0

